try {
  var savedTheme = localStorage.getItem('xor-docs-theme');
  document.documentElement.dataset.theme = ['light', 'dark'].includes(savedTheme) ? savedTheme : 'light';
} catch (_) { document.documentElement.dataset.theme = 'light'; }
