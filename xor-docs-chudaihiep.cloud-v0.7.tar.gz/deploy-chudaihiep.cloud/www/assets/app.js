const $=(s,root=document)=>root.querySelector(s);
const $$=(s,root=document)=>[...root.querySelectorAll(s)];
const lang=document.documentElement.lang;
const messages=JSON.parse($('#client-i18n').textContent);
const t=(key,values={})=>messages[key].replace(/\{(\w+)\}/g,(_,name)=>String(values[name]??''));
const normalize=s=>s.toLocaleLowerCase(lang).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replaceAll('đ','d');
const html=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
let toastTimer;
function toast(message){$('.toast').textContent=message;$('.toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('.toast').classList.remove('visible'),2800);}

const themeButton=$('.theme-toggle');
function syncTheme(){const dark=document.documentElement.dataset.theme==='dark';themeButton.setAttribute('aria-pressed',String(dark));themeButton.title=t(dark?'lightTheme':'darkTheme');themeButton.innerHTML=dark?'<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/></svg>':'<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" aria-hidden="true"><path d="M20 14A9 9 0 0 1 10 3a9 9 0 1 0 10 11Z"/></svg>';document.querySelector('meta[name="theme-color"]').content=dark?'#0a0a0a':'#f9f9f9';}
syncTheme();
themeButton.addEventListener('click',()=>{document.documentElement.dataset.theme=document.documentElement.dataset.theme==='dark'?'light':'dark';try{localStorage.setItem('xor-docs-theme',document.documentElement.dataset.theme);}catch(_){}syncTheme();});

const menu=$('.mobile-menu'),backdrop=$('.mobile-backdrop');
function setMenu(open){document.body.classList.toggle('menu-open',open);menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',t(open?'closeMenu':'openMenu'));backdrop.hidden=!open;$('#sidebar').inert=!open&&matchMedia('(max-width: 1024px)').matches;$('.main').inert=open;if(open){$('#sidebar a')?.focus();}}
setMenu(false);
menu.addEventListener('click',()=>setMenu(!document.body.classList.contains('menu-open')));
backdrop.addEventListener('click',()=>setMenu(false));
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.body.classList.contains('menu-open')){setMenu(false);menu.focus();}if(e.key==='Tab'&&document.body.classList.contains('menu-open')){const focusable=$$('#sidebar a, #sidebar summary').filter(el=>el.getClientRects().length);const first=focusable[0],last=focusable.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}});
matchMedia('(min-width: 1025px)').addEventListener('change',()=>setMenu(false));

const dialog=$('.search-dialog'),input=$('#search-input'),results=$('#search-results');
let searchIndex=null,searchPromise=null,activeResult=-1,opener=null;
async function loadSearch(){if(searchIndex)return searchIndex;if(searchPromise)return searchPromise;searchPromise=fetch(document.body.dataset.searchIndex).then(r=>{if(!r.ok)throw new Error('search');return r.json();}).then(data=>{searchIndex=data.map(d=>({...d,normalizedTitle:normalize(d.title),normalizedSummary:normalize(d.summary),normalizedBody:normalize(d.body)}));return searchIndex;}).catch(error=>{searchPromise=null;throw error;});return searchPromise;}
async function openSearch(){opener=document.activeElement;setMenu(false);dialog.showModal();input.value='';input.focus();results.innerHTML=`<p class="search-message">${html(t('loading'))}</p>`;try{await loadSearch();renderResults();}catch(_){results.innerHTML=`<p class="search-message">${html(t('searchError'))} <a href="${html(document.body.dataset.home)}">${html(t('catalogLink'))}</a>.</p>`;}}
$$('[data-search-open]').forEach(b=>b.addEventListener('click',openSearch));
document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();dialog.open?dialog.close():openSearch();}else if(e.key==='/'&&!dialog.open&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)){e.preventDefault();openSearch();}});
dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
dialog.addEventListener('close',()=>opener?.focus());
$('.search-top').addEventListener('submit',e=>{if(e.submitter?.classList.contains('dialog-close'))return;e.preventDefault();});
function renderResults(){if(!searchIndex)return;const query=normalize(input.value.trim()),terms=query.split(/\s+/).filter(Boolean);let list=searchIndex;if(query){list=searchIndex.map(d=>{const text=d.normalizedTitle+' '+d.normalizedSummary+' '+d.normalizedBody;const matches=terms.every(t=>text.includes(t));const score=d.normalizedTitle.includes(query)?100:terms.reduce((n,t)=>n+(d.normalizedTitle.includes(t)?15:d.normalizedSummary.includes(t)?5:1),0);return {...d,score:matches?score:0};}).filter(d=>d.score>0).sort((a,b)=>b.score-a.score);}else{const ids=['bat-dau-nhanh','dang-nhap','may-ao','mang','luu-tru'];list=ids.map(id=>searchIndex.find(d=>d.id===id)).filter(Boolean);}const total=list.length;list=list.slice(0,10);activeResult=-1;if(!list.length){results.innerHTML=`<div class="search-empty"><strong>${html(t('noResults',{query:input.value.trim()}))}</strong><p>${html(t('trySearch'))}</p></div>`;return;}results.innerHTML=`<div class="search-label">${html(query?t('results',{count:total})+(total>10?t('topResults'):''):t('suggestions'))}</div>${list.map(d=>`<a class="search-result" href="${html(d.url)}"><span class="search-result-icon">↗</span><div><span class="result-group">${html(d.group)}</span><strong>${html(d.title)}</strong><p>${html(d.summary)}</p></div><span class="result-enter">↵</span></a>`).join('')}`;}
input.addEventListener('input',renderResults);
input.addEventListener('keydown',e=>{const links=$$('.search-result');if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();if(!links.length)return;activeResult=(activeResult+(e.key==='ArrowDown'?1:-1)+links.length)%links.length;links.forEach((el,i)=>el.classList.toggle('selected',i===activeResult));links[activeResult].scrollIntoView({block:'nearest'});}else if(e.key==='Enter'){e.preventDefault();(links[activeResult]||links[0])?.click();}});

$('.copy-link')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(location.href);toast(t('copied'));}catch(_){toast(t('copyError'));}});
const sections=$$('.doc-section');
if(sections.length){const observer=new IntersectionObserver(entries=>{const visible=entries.filter(e=>e.isIntersecting).sort((a,b)=>a.boundingClientRect.top-b.boundingClientRect.top);if(visible.length){const id=visible[0].target.id;$$('.toc nav a').forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+id));}},{rootMargin:'-90px 0px -65% 0px',threshold:0});sections.forEach(s=>observer.observe(s));}
const activeNav=$('.nav-link.active');
if(activeNav){const sidebar=$('.sidebar-scroll');const top=activeNav.offsetTop;if(top>sidebar.clientHeight-120)sidebar.scrollTop=top-sidebar.clientHeight/2;}

// Both editions share section IDs, so language links retain the current anchor.
function syncLanguageLinks(){
  $$('.language-switch a').forEach(link=>{
    const url=new URL(link.href);
    url.hash=location.hash;
    link.href=url.pathname+url.hash;
  });
}
syncLanguageLinks();
window.addEventListener('hashchange',syncLanguageLinks);
